"use strict";
//Notify
$.notify({
	icon: 'icon-bell',
	title: 'Kaiadmin',
	message: 'Premium Bootstrap 5 Admin Dashboard',
},{
	type: 'secondary',
	placement: {
		from: "bottom",
		align: "right"
	},
	time: 1000,
});
